# generated from rosidl_generator_py/resource/_idl.py.em
# with input from ab_udp_msg:msg/EsCameraConfig.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import math  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_EsCameraConfig(type):
    """Metaclass of message 'EsCameraConfig'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('ab_udp_msg')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'ab_udp_msg.msg.EsCameraConfig')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__es_camera_config
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__es_camera_config
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__es_camera_config
            cls._TYPE_SUPPORT = module.type_support_msg__msg__es_camera_config
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__es_camera_config

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class EsCameraConfig(metaclass=Metaclass_EsCameraConfig):
    """Message class 'EsCameraConfig'."""

    __slots__ = [
        '_focal_length',
        '_camera_height',
        '_ppx',
        '_ppy',
        '_image_width',
        '_image_height',
    ]

    _fields_and_field_types = {
        'focal_length': 'float',
        'camera_height': 'float',
        'ppx': 'float',
        'ppy': 'float',
        'image_width': 'uint32',
        'image_height': 'uint32',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint32'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint32'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.focal_length = kwargs.get('focal_length', float())
        self.camera_height = kwargs.get('camera_height', float())
        self.ppx = kwargs.get('ppx', float())
        self.ppy = kwargs.get('ppy', float())
        self.image_width = kwargs.get('image_width', int())
        self.image_height = kwargs.get('image_height', int())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.focal_length != other.focal_length:
            return False
        if self.camera_height != other.camera_height:
            return False
        if self.ppx != other.ppx:
            return False
        if self.ppy != other.ppy:
            return False
        if self.image_width != other.image_width:
            return False
        if self.image_height != other.image_height:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def focal_length(self):
        """Message field 'focal_length'."""
        return self._focal_length

    @focal_length.setter
    def focal_length(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'focal_length' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'focal_length' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._focal_length = value

    @builtins.property
    def camera_height(self):
        """Message field 'camera_height'."""
        return self._camera_height

    @camera_height.setter
    def camera_height(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'camera_height' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'camera_height' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._camera_height = value

    @builtins.property
    def ppx(self):
        """Message field 'ppx'."""
        return self._ppx

    @ppx.setter
    def ppx(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'ppx' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'ppx' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._ppx = value

    @builtins.property
    def ppy(self):
        """Message field 'ppy'."""
        return self._ppy

    @ppy.setter
    def ppy(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'ppy' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'ppy' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._ppy = value

    @builtins.property
    def image_width(self):
        """Message field 'image_width'."""
        return self._image_width

    @image_width.setter
    def image_width(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'image_width' field must be of type 'int'"
            assert value >= 0 and value < 4294967296, \
                "The 'image_width' field must be an unsigned integer in [0, 4294967295]"
        self._image_width = value

    @builtins.property
    def image_height(self):
        """Message field 'image_height'."""
        return self._image_height

    @image_height.setter
    def image_height(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'image_height' field must be of type 'int'"
            assert value >= 0 and value < 4294967296, \
                "The 'image_height' field must be an unsigned integer in [0, 4294967295]"
        self._image_height = value
