// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from ab_udp_msg:msg/ABSignalsV1.idl
// generated code does not contain a copyright notice

#ifndef AB_UDP_MSG__MSG__DETAIL__AB_SIGNALS_V1__STRUCT_H_
#define AB_UDP_MSG__MSG__DETAIL__AB_SIGNALS_V1__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 's_base_header'
#include "ab_udp_msg/msg/detail/ab_msg_header__struct.h"
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'camera_config'
#include "ab_udp_msg/msg/detail/es_camera_config__struct.h"
// Member 'vehicle_signals'
#include "ab_udp_msg/msg/detail/es_vehicle_signals__struct.h"

/// Struct defined in msg/ABSignalsV1 in the package ab_udp_msg.
typedef struct ab_udp_msg__msg__ABSignalsV1
{
  ab_udp_msg__msg__ABMsgHeader s_base_header;
  std_msgs__msg__Header header;
  ab_udp_msg__msg__EsCameraConfig camera_config;
  ab_udp_msg__msg__EsVehicleSignals vehicle_signals;
} ab_udp_msg__msg__ABSignalsV1;

// Struct for a sequence of ab_udp_msg__msg__ABSignalsV1.
typedef struct ab_udp_msg__msg__ABSignalsV1__Sequence
{
  ab_udp_msg__msg__ABSignalsV1 * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} ab_udp_msg__msg__ABSignalsV1__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // AB_UDP_MSG__MSG__DETAIL__AB_SIGNALS_V1__STRUCT_H_
