// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from ab_udp_msg:msg/EsVehicleSignals.idl
// generated code does not contain a copyright notice

#ifndef AB_UDP_MSG__MSG__DETAIL__ES_VEHICLE_SIGNALS__STRUCT_HPP_
#define AB_UDP_MSG__MSG__DETAIL__ES_VEHICLE_SIGNALS__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__ab_udp_msg__msg__EsVehicleSignals __attribute__((deprecated))
#else
# define DEPRECATED__ab_udp_msg__msg__EsVehicleSignals __declspec(deprecated)
#endif

namespace ab_udp_msg
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct EsVehicleSignals_
{
  using Type = EsVehicleSignals_<ContainerAllocator>;

  explicit EsVehicleSignals_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->longitudinal_velocity = 0.0f;
      this->longitudinal_acceleration = 0.0f;
      this->yaw_rate = 0.0f;
      this->speed_o_speed = 0.0f;
    }
  }

  explicit EsVehicleSignals_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->longitudinal_velocity = 0.0f;
      this->longitudinal_acceleration = 0.0f;
      this->yaw_rate = 0.0f;
      this->speed_o_speed = 0.0f;
    }
  }

  // field types and members
  using _longitudinal_velocity_type =
    float;
  _longitudinal_velocity_type longitudinal_velocity;
  using _longitudinal_acceleration_type =
    float;
  _longitudinal_acceleration_type longitudinal_acceleration;
  using _yaw_rate_type =
    float;
  _yaw_rate_type yaw_rate;
  using _speed_o_speed_type =
    float;
  _speed_o_speed_type speed_o_speed;

  // setters for named parameter idiom
  Type & set__longitudinal_velocity(
    const float & _arg)
  {
    this->longitudinal_velocity = _arg;
    return *this;
  }
  Type & set__longitudinal_acceleration(
    const float & _arg)
  {
    this->longitudinal_acceleration = _arg;
    return *this;
  }
  Type & set__yaw_rate(
    const float & _arg)
  {
    this->yaw_rate = _arg;
    return *this;
  }
  Type & set__speed_o_speed(
    const float & _arg)
  {
    this->speed_o_speed = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    ab_udp_msg::msg::EsVehicleSignals_<ContainerAllocator> *;
  using ConstRawPtr =
    const ab_udp_msg::msg::EsVehicleSignals_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<ab_udp_msg::msg::EsVehicleSignals_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<ab_udp_msg::msg::EsVehicleSignals_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      ab_udp_msg::msg::EsVehicleSignals_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<ab_udp_msg::msg::EsVehicleSignals_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      ab_udp_msg::msg::EsVehicleSignals_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<ab_udp_msg::msg::EsVehicleSignals_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<ab_udp_msg::msg::EsVehicleSignals_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<ab_udp_msg::msg::EsVehicleSignals_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__ab_udp_msg__msg__EsVehicleSignals
    std::shared_ptr<ab_udp_msg::msg::EsVehicleSignals_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__ab_udp_msg__msg__EsVehicleSignals
    std::shared_ptr<ab_udp_msg::msg::EsVehicleSignals_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const EsVehicleSignals_ & other) const
  {
    if (this->longitudinal_velocity != other.longitudinal_velocity) {
      return false;
    }
    if (this->longitudinal_acceleration != other.longitudinal_acceleration) {
      return false;
    }
    if (this->yaw_rate != other.yaw_rate) {
      return false;
    }
    if (this->speed_o_speed != other.speed_o_speed) {
      return false;
    }
    return true;
  }
  bool operator!=(const EsVehicleSignals_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct EsVehicleSignals_

// alias to use template instance with default allocator
using EsVehicleSignals =
  ab_udp_msg::msg::EsVehicleSignals_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace ab_udp_msg

#endif  // AB_UDP_MSG__MSG__DETAIL__ES_VEHICLE_SIGNALS__STRUCT_HPP_
