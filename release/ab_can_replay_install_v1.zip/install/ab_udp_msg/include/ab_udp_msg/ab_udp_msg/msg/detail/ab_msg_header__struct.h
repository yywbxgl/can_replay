// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from ab_udp_msg:msg/ABMsgHeader.idl
// generated code does not contain a copyright notice

#ifndef AB_UDP_MSG__MSG__DETAIL__AB_MSG_HEADER__STRUCT_H_
#define AB_UDP_MSG__MSG__DETAIL__AB_MSG_HEADER__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 's_frame_name'
// Member 's_module_version'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/ABMsgHeader in the package ab_udp_msg.
typedef struct ab_udp_msg__msg__ABMsgHeader
{
  float interface_struct_version;
  uint64_t frame_number;
  rosidl_runtime_c__String s_frame_name;
  rosidl_runtime_c__String s_module_version;
} ab_udp_msg__msg__ABMsgHeader;

// Struct for a sequence of ab_udp_msg__msg__ABMsgHeader.
typedef struct ab_udp_msg__msg__ABMsgHeader__Sequence
{
  ab_udp_msg__msg__ABMsgHeader * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} ab_udp_msg__msg__ABMsgHeader__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // AB_UDP_MSG__MSG__DETAIL__AB_MSG_HEADER__STRUCT_H_
