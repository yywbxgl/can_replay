// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from ab_udp_msg:msg/EsCameraConfig.idl
// generated code does not contain a copyright notice

#ifndef AB_UDP_MSG__MSG__DETAIL__ES_CAMERA_CONFIG__TRAITS_HPP_
#define AB_UDP_MSG__MSG__DETAIL__ES_CAMERA_CONFIG__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "ab_udp_msg/msg/detail/es_camera_config__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace ab_udp_msg
{

namespace msg
{

inline void to_flow_style_yaml(
  const EsCameraConfig & msg,
  std::ostream & out)
{
  out << "{";
  // member: focal_length
  {
    out << "focal_length: ";
    rosidl_generator_traits::value_to_yaml(msg.focal_length, out);
    out << ", ";
  }

  // member: camera_height
  {
    out << "camera_height: ";
    rosidl_generator_traits::value_to_yaml(msg.camera_height, out);
    out << ", ";
  }

  // member: ppx
  {
    out << "ppx: ";
    rosidl_generator_traits::value_to_yaml(msg.ppx, out);
    out << ", ";
  }

  // member: ppy
  {
    out << "ppy: ";
    rosidl_generator_traits::value_to_yaml(msg.ppy, out);
    out << ", ";
  }

  // member: image_width
  {
    out << "image_width: ";
    rosidl_generator_traits::value_to_yaml(msg.image_width, out);
    out << ", ";
  }

  // member: image_height
  {
    out << "image_height: ";
    rosidl_generator_traits::value_to_yaml(msg.image_height, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const EsCameraConfig & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: focal_length
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "focal_length: ";
    rosidl_generator_traits::value_to_yaml(msg.focal_length, out);
    out << "\n";
  }

  // member: camera_height
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "camera_height: ";
    rosidl_generator_traits::value_to_yaml(msg.camera_height, out);
    out << "\n";
  }

  // member: ppx
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "ppx: ";
    rosidl_generator_traits::value_to_yaml(msg.ppx, out);
    out << "\n";
  }

  // member: ppy
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "ppy: ";
    rosidl_generator_traits::value_to_yaml(msg.ppy, out);
    out << "\n";
  }

  // member: image_width
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "image_width: ";
    rosidl_generator_traits::value_to_yaml(msg.image_width, out);
    out << "\n";
  }

  // member: image_height
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "image_height: ";
    rosidl_generator_traits::value_to_yaml(msg.image_height, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const EsCameraConfig & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace ab_udp_msg

namespace rosidl_generator_traits
{

[[deprecated("use ab_udp_msg::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const ab_udp_msg::msg::EsCameraConfig & msg,
  std::ostream & out, size_t indentation = 0)
{
  ab_udp_msg::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use ab_udp_msg::msg::to_yaml() instead")]]
inline std::string to_yaml(const ab_udp_msg::msg::EsCameraConfig & msg)
{
  return ab_udp_msg::msg::to_yaml(msg);
}

template<>
inline const char * data_type<ab_udp_msg::msg::EsCameraConfig>()
{
  return "ab_udp_msg::msg::EsCameraConfig";
}

template<>
inline const char * name<ab_udp_msg::msg::EsCameraConfig>()
{
  return "ab_udp_msg/msg/EsCameraConfig";
}

template<>
struct has_fixed_size<ab_udp_msg::msg::EsCameraConfig>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<ab_udp_msg::msg::EsCameraConfig>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<ab_udp_msg::msg::EsCameraConfig>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // AB_UDP_MSG__MSG__DETAIL__ES_CAMERA_CONFIG__TRAITS_HPP_
