// generated from rosidl_typesupport_fastrtps_c/resource/idl__rosidl_typesupport_fastrtps_c.h.em
// with input from ab_udp_msg:msg/EsVehicleSignals.idl
// generated code does not contain a copyright notice
#ifndef AB_UDP_MSG__MSG__DETAIL__ES_VEHICLE_SIGNALS__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
#define AB_UDP_MSG__MSG__DETAIL__ES_VEHICLE_SIGNALS__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_


#include <stddef.h>
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "ab_udp_msg/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_ab_udp_msg
size_t get_serialized_size_ab_udp_msg__msg__EsVehicleSignals(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_ab_udp_msg
size_t max_serialized_size_ab_udp_msg__msg__EsVehicleSignals(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_ab_udp_msg
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, ab_udp_msg, msg, EsVehicleSignals)();

#ifdef __cplusplus
}
#endif

#endif  // AB_UDP_MSG__MSG__DETAIL__ES_VEHICLE_SIGNALS__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
