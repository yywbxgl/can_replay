// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from ab_udp_msg:msg/ABSignalsV1.idl
// generated code does not contain a copyright notice

#ifndef AB_UDP_MSG__MSG__DETAIL__AB_SIGNALS_V1__BUILDER_HPP_
#define AB_UDP_MSG__MSG__DETAIL__AB_SIGNALS_V1__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "ab_udp_msg/msg/detail/ab_signals_v1__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace ab_udp_msg
{

namespace msg
{

namespace builder
{

class Init_ABSignalsV1_vehicle_signals
{
public:
  explicit Init_ABSignalsV1_vehicle_signals(::ab_udp_msg::msg::ABSignalsV1 & msg)
  : msg_(msg)
  {}
  ::ab_udp_msg::msg::ABSignalsV1 vehicle_signals(::ab_udp_msg::msg::ABSignalsV1::_vehicle_signals_type arg)
  {
    msg_.vehicle_signals = std::move(arg);
    return std::move(msg_);
  }

private:
  ::ab_udp_msg::msg::ABSignalsV1 msg_;
};

class Init_ABSignalsV1_camera_config
{
public:
  explicit Init_ABSignalsV1_camera_config(::ab_udp_msg::msg::ABSignalsV1 & msg)
  : msg_(msg)
  {}
  Init_ABSignalsV1_vehicle_signals camera_config(::ab_udp_msg::msg::ABSignalsV1::_camera_config_type arg)
  {
    msg_.camera_config = std::move(arg);
    return Init_ABSignalsV1_vehicle_signals(msg_);
  }

private:
  ::ab_udp_msg::msg::ABSignalsV1 msg_;
};

class Init_ABSignalsV1_header
{
public:
  explicit Init_ABSignalsV1_header(::ab_udp_msg::msg::ABSignalsV1 & msg)
  : msg_(msg)
  {}
  Init_ABSignalsV1_camera_config header(::ab_udp_msg::msg::ABSignalsV1::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_ABSignalsV1_camera_config(msg_);
  }

private:
  ::ab_udp_msg::msg::ABSignalsV1 msg_;
};

class Init_ABSignalsV1_s_base_header
{
public:
  Init_ABSignalsV1_s_base_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ABSignalsV1_header s_base_header(::ab_udp_msg::msg::ABSignalsV1::_s_base_header_type arg)
  {
    msg_.s_base_header = std::move(arg);
    return Init_ABSignalsV1_header(msg_);
  }

private:
  ::ab_udp_msg::msg::ABSignalsV1 msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::ab_udp_msg::msg::ABSignalsV1>()
{
  return ab_udp_msg::msg::builder::Init_ABSignalsV1_s_base_header();
}

}  // namespace ab_udp_msg

#endif  // AB_UDP_MSG__MSG__DETAIL__AB_SIGNALS_V1__BUILDER_HPP_
