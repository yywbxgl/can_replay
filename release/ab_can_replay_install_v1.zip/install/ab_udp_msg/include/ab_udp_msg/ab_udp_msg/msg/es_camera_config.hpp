// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef AB_UDP_MSG__MSG__ES_CAMERA_CONFIG_HPP_
#define AB_UDP_MSG__MSG__ES_CAMERA_CONFIG_HPP_

#include "ab_udp_msg/msg/detail/es_camera_config__struct.hpp"
#include "ab_udp_msg/msg/detail/es_camera_config__builder.hpp"
#include "ab_udp_msg/msg/detail/es_camera_config__traits.hpp"
#include "ab_udp_msg/msg/detail/es_camera_config__type_support.hpp"

#endif  // AB_UDP_MSG__MSG__ES_CAMERA_CONFIG_HPP_
