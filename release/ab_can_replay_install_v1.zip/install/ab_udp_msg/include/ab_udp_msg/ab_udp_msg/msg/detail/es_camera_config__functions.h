// generated from rosidl_generator_c/resource/idl__functions.h.em
// with input from ab_udp_msg:msg/EsCameraConfig.idl
// generated code does not contain a copyright notice

#ifndef AB_UDP_MSG__MSG__DETAIL__ES_CAMERA_CONFIG__FUNCTIONS_H_
#define AB_UDP_MSG__MSG__DETAIL__ES_CAMERA_CONFIG__FUNCTIONS_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stdlib.h>

#include "rosidl_runtime_c/visibility_control.h"
#include "ab_udp_msg/msg/rosidl_generator_c__visibility_control.h"

#include "ab_udp_msg/msg/detail/es_camera_config__struct.h"

/// Initialize msg/EsCameraConfig message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * ab_udp_msg__msg__EsCameraConfig
 * )) before or use
 * ab_udp_msg__msg__EsCameraConfig__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_ab_udp_msg
bool
ab_udp_msg__msg__EsCameraConfig__init(ab_udp_msg__msg__EsCameraConfig * msg);

/// Finalize msg/EsCameraConfig message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_ab_udp_msg
void
ab_udp_msg__msg__EsCameraConfig__fini(ab_udp_msg__msg__EsCameraConfig * msg);

/// Create msg/EsCameraConfig message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * ab_udp_msg__msg__EsCameraConfig__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_ab_udp_msg
ab_udp_msg__msg__EsCameraConfig *
ab_udp_msg__msg__EsCameraConfig__create();

/// Destroy msg/EsCameraConfig message.
/**
 * It calls
 * ab_udp_msg__msg__EsCameraConfig__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_ab_udp_msg
void
ab_udp_msg__msg__EsCameraConfig__destroy(ab_udp_msg__msg__EsCameraConfig * msg);

/// Check for msg/EsCameraConfig message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_ab_udp_msg
bool
ab_udp_msg__msg__EsCameraConfig__are_equal(const ab_udp_msg__msg__EsCameraConfig * lhs, const ab_udp_msg__msg__EsCameraConfig * rhs);

/// Copy a msg/EsCameraConfig message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_ab_udp_msg
bool
ab_udp_msg__msg__EsCameraConfig__copy(
  const ab_udp_msg__msg__EsCameraConfig * input,
  ab_udp_msg__msg__EsCameraConfig * output);

/// Initialize array of msg/EsCameraConfig messages.
/**
 * It allocates the memory for the number of elements and calls
 * ab_udp_msg__msg__EsCameraConfig__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_ab_udp_msg
bool
ab_udp_msg__msg__EsCameraConfig__Sequence__init(ab_udp_msg__msg__EsCameraConfig__Sequence * array, size_t size);

/// Finalize array of msg/EsCameraConfig messages.
/**
 * It calls
 * ab_udp_msg__msg__EsCameraConfig__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_ab_udp_msg
void
ab_udp_msg__msg__EsCameraConfig__Sequence__fini(ab_udp_msg__msg__EsCameraConfig__Sequence * array);

/// Create array of msg/EsCameraConfig messages.
/**
 * It allocates the memory for the array and calls
 * ab_udp_msg__msg__EsCameraConfig__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_ab_udp_msg
ab_udp_msg__msg__EsCameraConfig__Sequence *
ab_udp_msg__msg__EsCameraConfig__Sequence__create(size_t size);

/// Destroy array of msg/EsCameraConfig messages.
/**
 * It calls
 * ab_udp_msg__msg__EsCameraConfig__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_ab_udp_msg
void
ab_udp_msg__msg__EsCameraConfig__Sequence__destroy(ab_udp_msg__msg__EsCameraConfig__Sequence * array);

/// Check for msg/EsCameraConfig message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_ab_udp_msg
bool
ab_udp_msg__msg__EsCameraConfig__Sequence__are_equal(const ab_udp_msg__msg__EsCameraConfig__Sequence * lhs, const ab_udp_msg__msg__EsCameraConfig__Sequence * rhs);

/// Copy an array of msg/EsCameraConfig messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_ab_udp_msg
bool
ab_udp_msg__msg__EsCameraConfig__Sequence__copy(
  const ab_udp_msg__msg__EsCameraConfig__Sequence * input,
  ab_udp_msg__msg__EsCameraConfig__Sequence * output);

#ifdef __cplusplus
}
#endif

#endif  // AB_UDP_MSG__MSG__DETAIL__ES_CAMERA_CONFIG__FUNCTIONS_H_
