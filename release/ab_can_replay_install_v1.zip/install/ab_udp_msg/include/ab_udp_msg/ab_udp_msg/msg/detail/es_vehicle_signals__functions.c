// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from ab_udp_msg:msg/EsVehicleSignals.idl
// generated code does not contain a copyright notice
#include "ab_udp_msg/msg/detail/es_vehicle_signals__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


bool
ab_udp_msg__msg__EsVehicleSignals__init(ab_udp_msg__msg__EsVehicleSignals * msg)
{
  if (!msg) {
    return false;
  }
  // longitudinal_velocity
  // longitudinal_acceleration
  // yaw_rate
  // speed_o_speed
  return true;
}

void
ab_udp_msg__msg__EsVehicleSignals__fini(ab_udp_msg__msg__EsVehicleSignals * msg)
{
  if (!msg) {
    return;
  }
  // longitudinal_velocity
  // longitudinal_acceleration
  // yaw_rate
  // speed_o_speed
}

bool
ab_udp_msg__msg__EsVehicleSignals__are_equal(const ab_udp_msg__msg__EsVehicleSignals * lhs, const ab_udp_msg__msg__EsVehicleSignals * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // longitudinal_velocity
  if (lhs->longitudinal_velocity != rhs->longitudinal_velocity) {
    return false;
  }
  // longitudinal_acceleration
  if (lhs->longitudinal_acceleration != rhs->longitudinal_acceleration) {
    return false;
  }
  // yaw_rate
  if (lhs->yaw_rate != rhs->yaw_rate) {
    return false;
  }
  // speed_o_speed
  if (lhs->speed_o_speed != rhs->speed_o_speed) {
    return false;
  }
  return true;
}

bool
ab_udp_msg__msg__EsVehicleSignals__copy(
  const ab_udp_msg__msg__EsVehicleSignals * input,
  ab_udp_msg__msg__EsVehicleSignals * output)
{
  if (!input || !output) {
    return false;
  }
  // longitudinal_velocity
  output->longitudinal_velocity = input->longitudinal_velocity;
  // longitudinal_acceleration
  output->longitudinal_acceleration = input->longitudinal_acceleration;
  // yaw_rate
  output->yaw_rate = input->yaw_rate;
  // speed_o_speed
  output->speed_o_speed = input->speed_o_speed;
  return true;
}

ab_udp_msg__msg__EsVehicleSignals *
ab_udp_msg__msg__EsVehicleSignals__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  ab_udp_msg__msg__EsVehicleSignals * msg = (ab_udp_msg__msg__EsVehicleSignals *)allocator.allocate(sizeof(ab_udp_msg__msg__EsVehicleSignals), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(ab_udp_msg__msg__EsVehicleSignals));
  bool success = ab_udp_msg__msg__EsVehicleSignals__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
ab_udp_msg__msg__EsVehicleSignals__destroy(ab_udp_msg__msg__EsVehicleSignals * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    ab_udp_msg__msg__EsVehicleSignals__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
ab_udp_msg__msg__EsVehicleSignals__Sequence__init(ab_udp_msg__msg__EsVehicleSignals__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  ab_udp_msg__msg__EsVehicleSignals * data = NULL;

  if (size) {
    data = (ab_udp_msg__msg__EsVehicleSignals *)allocator.zero_allocate(size, sizeof(ab_udp_msg__msg__EsVehicleSignals), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = ab_udp_msg__msg__EsVehicleSignals__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        ab_udp_msg__msg__EsVehicleSignals__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
ab_udp_msg__msg__EsVehicleSignals__Sequence__fini(ab_udp_msg__msg__EsVehicleSignals__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      ab_udp_msg__msg__EsVehicleSignals__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

ab_udp_msg__msg__EsVehicleSignals__Sequence *
ab_udp_msg__msg__EsVehicleSignals__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  ab_udp_msg__msg__EsVehicleSignals__Sequence * array = (ab_udp_msg__msg__EsVehicleSignals__Sequence *)allocator.allocate(sizeof(ab_udp_msg__msg__EsVehicleSignals__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = ab_udp_msg__msg__EsVehicleSignals__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
ab_udp_msg__msg__EsVehicleSignals__Sequence__destroy(ab_udp_msg__msg__EsVehicleSignals__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    ab_udp_msg__msg__EsVehicleSignals__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
ab_udp_msg__msg__EsVehicleSignals__Sequence__are_equal(const ab_udp_msg__msg__EsVehicleSignals__Sequence * lhs, const ab_udp_msg__msg__EsVehicleSignals__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!ab_udp_msg__msg__EsVehicleSignals__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
ab_udp_msg__msg__EsVehicleSignals__Sequence__copy(
  const ab_udp_msg__msg__EsVehicleSignals__Sequence * input,
  ab_udp_msg__msg__EsVehicleSignals__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(ab_udp_msg__msg__EsVehicleSignals);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    ab_udp_msg__msg__EsVehicleSignals * data =
      (ab_udp_msg__msg__EsVehicleSignals *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!ab_udp_msg__msg__EsVehicleSignals__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          ab_udp_msg__msg__EsVehicleSignals__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!ab_udp_msg__msg__EsVehicleSignals__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
