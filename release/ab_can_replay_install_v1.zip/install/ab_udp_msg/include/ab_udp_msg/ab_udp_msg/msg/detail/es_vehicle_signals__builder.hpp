// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from ab_udp_msg:msg/EsVehicleSignals.idl
// generated code does not contain a copyright notice

#ifndef AB_UDP_MSG__MSG__DETAIL__ES_VEHICLE_SIGNALS__BUILDER_HPP_
#define AB_UDP_MSG__MSG__DETAIL__ES_VEHICLE_SIGNALS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "ab_udp_msg/msg/detail/es_vehicle_signals__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace ab_udp_msg
{

namespace msg
{

namespace builder
{

class Init_EsVehicleSignals_speed_o_speed
{
public:
  explicit Init_EsVehicleSignals_speed_o_speed(::ab_udp_msg::msg::EsVehicleSignals & msg)
  : msg_(msg)
  {}
  ::ab_udp_msg::msg::EsVehicleSignals speed_o_speed(::ab_udp_msg::msg::EsVehicleSignals::_speed_o_speed_type arg)
  {
    msg_.speed_o_speed = std::move(arg);
    return std::move(msg_);
  }

private:
  ::ab_udp_msg::msg::EsVehicleSignals msg_;
};

class Init_EsVehicleSignals_yaw_rate
{
public:
  explicit Init_EsVehicleSignals_yaw_rate(::ab_udp_msg::msg::EsVehicleSignals & msg)
  : msg_(msg)
  {}
  Init_EsVehicleSignals_speed_o_speed yaw_rate(::ab_udp_msg::msg::EsVehicleSignals::_yaw_rate_type arg)
  {
    msg_.yaw_rate = std::move(arg);
    return Init_EsVehicleSignals_speed_o_speed(msg_);
  }

private:
  ::ab_udp_msg::msg::EsVehicleSignals msg_;
};

class Init_EsVehicleSignals_longitudinal_acceleration
{
public:
  explicit Init_EsVehicleSignals_longitudinal_acceleration(::ab_udp_msg::msg::EsVehicleSignals & msg)
  : msg_(msg)
  {}
  Init_EsVehicleSignals_yaw_rate longitudinal_acceleration(::ab_udp_msg::msg::EsVehicleSignals::_longitudinal_acceleration_type arg)
  {
    msg_.longitudinal_acceleration = std::move(arg);
    return Init_EsVehicleSignals_yaw_rate(msg_);
  }

private:
  ::ab_udp_msg::msg::EsVehicleSignals msg_;
};

class Init_EsVehicleSignals_longitudinal_velocity
{
public:
  Init_EsVehicleSignals_longitudinal_velocity()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_EsVehicleSignals_longitudinal_acceleration longitudinal_velocity(::ab_udp_msg::msg::EsVehicleSignals::_longitudinal_velocity_type arg)
  {
    msg_.longitudinal_velocity = std::move(arg);
    return Init_EsVehicleSignals_longitudinal_acceleration(msg_);
  }

private:
  ::ab_udp_msg::msg::EsVehicleSignals msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::ab_udp_msg::msg::EsVehicleSignals>()
{
  return ab_udp_msg::msg::builder::Init_EsVehicleSignals_longitudinal_velocity();
}

}  // namespace ab_udp_msg

#endif  // AB_UDP_MSG__MSG__DETAIL__ES_VEHICLE_SIGNALS__BUILDER_HPP_
