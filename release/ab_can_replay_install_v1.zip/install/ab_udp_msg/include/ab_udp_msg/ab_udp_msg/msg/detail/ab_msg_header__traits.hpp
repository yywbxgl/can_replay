// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from ab_udp_msg:msg/ABMsgHeader.idl
// generated code does not contain a copyright notice

#ifndef AB_UDP_MSG__MSG__DETAIL__AB_MSG_HEADER__TRAITS_HPP_
#define AB_UDP_MSG__MSG__DETAIL__AB_MSG_HEADER__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "ab_udp_msg/msg/detail/ab_msg_header__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace ab_udp_msg
{

namespace msg
{

inline void to_flow_style_yaml(
  const ABMsgHeader & msg,
  std::ostream & out)
{
  out << "{";
  // member: interface_struct_version
  {
    out << "interface_struct_version: ";
    rosidl_generator_traits::value_to_yaml(msg.interface_struct_version, out);
    out << ", ";
  }

  // member: frame_number
  {
    out << "frame_number: ";
    rosidl_generator_traits::value_to_yaml(msg.frame_number, out);
    out << ", ";
  }

  // member: s_frame_name
  {
    out << "s_frame_name: ";
    rosidl_generator_traits::value_to_yaml(msg.s_frame_name, out);
    out << ", ";
  }

  // member: s_module_version
  {
    out << "s_module_version: ";
    rosidl_generator_traits::value_to_yaml(msg.s_module_version, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ABMsgHeader & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: interface_struct_version
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "interface_struct_version: ";
    rosidl_generator_traits::value_to_yaml(msg.interface_struct_version, out);
    out << "\n";
  }

  // member: frame_number
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "frame_number: ";
    rosidl_generator_traits::value_to_yaml(msg.frame_number, out);
    out << "\n";
  }

  // member: s_frame_name
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "s_frame_name: ";
    rosidl_generator_traits::value_to_yaml(msg.s_frame_name, out);
    out << "\n";
  }

  // member: s_module_version
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "s_module_version: ";
    rosidl_generator_traits::value_to_yaml(msg.s_module_version, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ABMsgHeader & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace ab_udp_msg

namespace rosidl_generator_traits
{

[[deprecated("use ab_udp_msg::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const ab_udp_msg::msg::ABMsgHeader & msg,
  std::ostream & out, size_t indentation = 0)
{
  ab_udp_msg::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use ab_udp_msg::msg::to_yaml() instead")]]
inline std::string to_yaml(const ab_udp_msg::msg::ABMsgHeader & msg)
{
  return ab_udp_msg::msg::to_yaml(msg);
}

template<>
inline const char * data_type<ab_udp_msg::msg::ABMsgHeader>()
{
  return "ab_udp_msg::msg::ABMsgHeader";
}

template<>
inline const char * name<ab_udp_msg::msg::ABMsgHeader>()
{
  return "ab_udp_msg/msg/ABMsgHeader";
}

template<>
struct has_fixed_size<ab_udp_msg::msg::ABMsgHeader>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<ab_udp_msg::msg::ABMsgHeader>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<ab_udp_msg::msg::ABMsgHeader>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // AB_UDP_MSG__MSG__DETAIL__AB_MSG_HEADER__TRAITS_HPP_
