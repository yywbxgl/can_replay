// generated from rosidl_generator_c/resource/idl.h.em
// with input from ab_udp_msg:msg/EsVehicleSignals.idl
// generated code does not contain a copyright notice

#ifndef AB_UDP_MSG__MSG__ES_VEHICLE_SIGNALS_H_
#define AB_UDP_MSG__MSG__ES_VEHICLE_SIGNALS_H_

#include "ab_udp_msg/msg/detail/es_vehicle_signals__struct.h"
#include "ab_udp_msg/msg/detail/es_vehicle_signals__functions.h"
#include "ab_udp_msg/msg/detail/es_vehicle_signals__type_support.h"

#endif  // AB_UDP_MSG__MSG__ES_VEHICLE_SIGNALS_H_
