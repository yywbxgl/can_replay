// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from ab_udp_msg:msg/ABSignalsV1.idl
// generated code does not contain a copyright notice
#include "ab_udp_msg/msg/detail/ab_signals_v1__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `s_base_header`
#include "ab_udp_msg/msg/detail/ab_msg_header__functions.h"
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"
// Member `camera_config`
#include "ab_udp_msg/msg/detail/es_camera_config__functions.h"
// Member `vehicle_signals`
#include "ab_udp_msg/msg/detail/es_vehicle_signals__functions.h"

bool
ab_udp_msg__msg__ABSignalsV1__init(ab_udp_msg__msg__ABSignalsV1 * msg)
{
  if (!msg) {
    return false;
  }
  // s_base_header
  if (!ab_udp_msg__msg__ABMsgHeader__init(&msg->s_base_header)) {
    ab_udp_msg__msg__ABSignalsV1__fini(msg);
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    ab_udp_msg__msg__ABSignalsV1__fini(msg);
    return false;
  }
  // camera_config
  if (!ab_udp_msg__msg__EsCameraConfig__init(&msg->camera_config)) {
    ab_udp_msg__msg__ABSignalsV1__fini(msg);
    return false;
  }
  // vehicle_signals
  if (!ab_udp_msg__msg__EsVehicleSignals__init(&msg->vehicle_signals)) {
    ab_udp_msg__msg__ABSignalsV1__fini(msg);
    return false;
  }
  return true;
}

void
ab_udp_msg__msg__ABSignalsV1__fini(ab_udp_msg__msg__ABSignalsV1 * msg)
{
  if (!msg) {
    return;
  }
  // s_base_header
  ab_udp_msg__msg__ABMsgHeader__fini(&msg->s_base_header);
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // camera_config
  ab_udp_msg__msg__EsCameraConfig__fini(&msg->camera_config);
  // vehicle_signals
  ab_udp_msg__msg__EsVehicleSignals__fini(&msg->vehicle_signals);
}

bool
ab_udp_msg__msg__ABSignalsV1__are_equal(const ab_udp_msg__msg__ABSignalsV1 * lhs, const ab_udp_msg__msg__ABSignalsV1 * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // s_base_header
  if (!ab_udp_msg__msg__ABMsgHeader__are_equal(
      &(lhs->s_base_header), &(rhs->s_base_header)))
  {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // camera_config
  if (!ab_udp_msg__msg__EsCameraConfig__are_equal(
      &(lhs->camera_config), &(rhs->camera_config)))
  {
    return false;
  }
  // vehicle_signals
  if (!ab_udp_msg__msg__EsVehicleSignals__are_equal(
      &(lhs->vehicle_signals), &(rhs->vehicle_signals)))
  {
    return false;
  }
  return true;
}

bool
ab_udp_msg__msg__ABSignalsV1__copy(
  const ab_udp_msg__msg__ABSignalsV1 * input,
  ab_udp_msg__msg__ABSignalsV1 * output)
{
  if (!input || !output) {
    return false;
  }
  // s_base_header
  if (!ab_udp_msg__msg__ABMsgHeader__copy(
      &(input->s_base_header), &(output->s_base_header)))
  {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // camera_config
  if (!ab_udp_msg__msg__EsCameraConfig__copy(
      &(input->camera_config), &(output->camera_config)))
  {
    return false;
  }
  // vehicle_signals
  if (!ab_udp_msg__msg__EsVehicleSignals__copy(
      &(input->vehicle_signals), &(output->vehicle_signals)))
  {
    return false;
  }
  return true;
}

ab_udp_msg__msg__ABSignalsV1 *
ab_udp_msg__msg__ABSignalsV1__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  ab_udp_msg__msg__ABSignalsV1 * msg = (ab_udp_msg__msg__ABSignalsV1 *)allocator.allocate(sizeof(ab_udp_msg__msg__ABSignalsV1), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(ab_udp_msg__msg__ABSignalsV1));
  bool success = ab_udp_msg__msg__ABSignalsV1__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
ab_udp_msg__msg__ABSignalsV1__destroy(ab_udp_msg__msg__ABSignalsV1 * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    ab_udp_msg__msg__ABSignalsV1__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
ab_udp_msg__msg__ABSignalsV1__Sequence__init(ab_udp_msg__msg__ABSignalsV1__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  ab_udp_msg__msg__ABSignalsV1 * data = NULL;

  if (size) {
    data = (ab_udp_msg__msg__ABSignalsV1 *)allocator.zero_allocate(size, sizeof(ab_udp_msg__msg__ABSignalsV1), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = ab_udp_msg__msg__ABSignalsV1__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        ab_udp_msg__msg__ABSignalsV1__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
ab_udp_msg__msg__ABSignalsV1__Sequence__fini(ab_udp_msg__msg__ABSignalsV1__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      ab_udp_msg__msg__ABSignalsV1__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

ab_udp_msg__msg__ABSignalsV1__Sequence *
ab_udp_msg__msg__ABSignalsV1__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  ab_udp_msg__msg__ABSignalsV1__Sequence * array = (ab_udp_msg__msg__ABSignalsV1__Sequence *)allocator.allocate(sizeof(ab_udp_msg__msg__ABSignalsV1__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = ab_udp_msg__msg__ABSignalsV1__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
ab_udp_msg__msg__ABSignalsV1__Sequence__destroy(ab_udp_msg__msg__ABSignalsV1__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    ab_udp_msg__msg__ABSignalsV1__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
ab_udp_msg__msg__ABSignalsV1__Sequence__are_equal(const ab_udp_msg__msg__ABSignalsV1__Sequence * lhs, const ab_udp_msg__msg__ABSignalsV1__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!ab_udp_msg__msg__ABSignalsV1__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
ab_udp_msg__msg__ABSignalsV1__Sequence__copy(
  const ab_udp_msg__msg__ABSignalsV1__Sequence * input,
  ab_udp_msg__msg__ABSignalsV1__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(ab_udp_msg__msg__ABSignalsV1);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    ab_udp_msg__msg__ABSignalsV1 * data =
      (ab_udp_msg__msg__ABSignalsV1 *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!ab_udp_msg__msg__ABSignalsV1__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          ab_udp_msg__msg__ABSignalsV1__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!ab_udp_msg__msg__ABSignalsV1__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
