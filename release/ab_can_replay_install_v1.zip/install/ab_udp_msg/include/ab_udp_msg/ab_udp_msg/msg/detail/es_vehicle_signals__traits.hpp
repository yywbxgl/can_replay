// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from ab_udp_msg:msg/EsVehicleSignals.idl
// generated code does not contain a copyright notice

#ifndef AB_UDP_MSG__MSG__DETAIL__ES_VEHICLE_SIGNALS__TRAITS_HPP_
#define AB_UDP_MSG__MSG__DETAIL__ES_VEHICLE_SIGNALS__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "ab_udp_msg/msg/detail/es_vehicle_signals__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace ab_udp_msg
{

namespace msg
{

inline void to_flow_style_yaml(
  const EsVehicleSignals & msg,
  std::ostream & out)
{
  out << "{";
  // member: longitudinal_velocity
  {
    out << "longitudinal_velocity: ";
    rosidl_generator_traits::value_to_yaml(msg.longitudinal_velocity, out);
    out << ", ";
  }

  // member: longitudinal_acceleration
  {
    out << "longitudinal_acceleration: ";
    rosidl_generator_traits::value_to_yaml(msg.longitudinal_acceleration, out);
    out << ", ";
  }

  // member: yaw_rate
  {
    out << "yaw_rate: ";
    rosidl_generator_traits::value_to_yaml(msg.yaw_rate, out);
    out << ", ";
  }

  // member: speed_o_speed
  {
    out << "speed_o_speed: ";
    rosidl_generator_traits::value_to_yaml(msg.speed_o_speed, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const EsVehicleSignals & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: longitudinal_velocity
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "longitudinal_velocity: ";
    rosidl_generator_traits::value_to_yaml(msg.longitudinal_velocity, out);
    out << "\n";
  }

  // member: longitudinal_acceleration
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "longitudinal_acceleration: ";
    rosidl_generator_traits::value_to_yaml(msg.longitudinal_acceleration, out);
    out << "\n";
  }

  // member: yaw_rate
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "yaw_rate: ";
    rosidl_generator_traits::value_to_yaml(msg.yaw_rate, out);
    out << "\n";
  }

  // member: speed_o_speed
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "speed_o_speed: ";
    rosidl_generator_traits::value_to_yaml(msg.speed_o_speed, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const EsVehicleSignals & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace ab_udp_msg

namespace rosidl_generator_traits
{

[[deprecated("use ab_udp_msg::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const ab_udp_msg::msg::EsVehicleSignals & msg,
  std::ostream & out, size_t indentation = 0)
{
  ab_udp_msg::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use ab_udp_msg::msg::to_yaml() instead")]]
inline std::string to_yaml(const ab_udp_msg::msg::EsVehicleSignals & msg)
{
  return ab_udp_msg::msg::to_yaml(msg);
}

template<>
inline const char * data_type<ab_udp_msg::msg::EsVehicleSignals>()
{
  return "ab_udp_msg::msg::EsVehicleSignals";
}

template<>
inline const char * name<ab_udp_msg::msg::EsVehicleSignals>()
{
  return "ab_udp_msg/msg/EsVehicleSignals";
}

template<>
struct has_fixed_size<ab_udp_msg::msg::EsVehicleSignals>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<ab_udp_msg::msg::EsVehicleSignals>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<ab_udp_msg::msg::EsVehicleSignals>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // AB_UDP_MSG__MSG__DETAIL__ES_VEHICLE_SIGNALS__TRAITS_HPP_
