// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from ab_udp_msg:msg/ABMsgHeader.idl
// generated code does not contain a copyright notice

#ifndef AB_UDP_MSG__MSG__DETAIL__AB_MSG_HEADER__BUILDER_HPP_
#define AB_UDP_MSG__MSG__DETAIL__AB_MSG_HEADER__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "ab_udp_msg/msg/detail/ab_msg_header__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace ab_udp_msg
{

namespace msg
{

namespace builder
{

class Init_ABMsgHeader_s_module_version
{
public:
  explicit Init_ABMsgHeader_s_module_version(::ab_udp_msg::msg::ABMsgHeader & msg)
  : msg_(msg)
  {}
  ::ab_udp_msg::msg::ABMsgHeader s_module_version(::ab_udp_msg::msg::ABMsgHeader::_s_module_version_type arg)
  {
    msg_.s_module_version = std::move(arg);
    return std::move(msg_);
  }

private:
  ::ab_udp_msg::msg::ABMsgHeader msg_;
};

class Init_ABMsgHeader_s_frame_name
{
public:
  explicit Init_ABMsgHeader_s_frame_name(::ab_udp_msg::msg::ABMsgHeader & msg)
  : msg_(msg)
  {}
  Init_ABMsgHeader_s_module_version s_frame_name(::ab_udp_msg::msg::ABMsgHeader::_s_frame_name_type arg)
  {
    msg_.s_frame_name = std::move(arg);
    return Init_ABMsgHeader_s_module_version(msg_);
  }

private:
  ::ab_udp_msg::msg::ABMsgHeader msg_;
};

class Init_ABMsgHeader_frame_number
{
public:
  explicit Init_ABMsgHeader_frame_number(::ab_udp_msg::msg::ABMsgHeader & msg)
  : msg_(msg)
  {}
  Init_ABMsgHeader_s_frame_name frame_number(::ab_udp_msg::msg::ABMsgHeader::_frame_number_type arg)
  {
    msg_.frame_number = std::move(arg);
    return Init_ABMsgHeader_s_frame_name(msg_);
  }

private:
  ::ab_udp_msg::msg::ABMsgHeader msg_;
};

class Init_ABMsgHeader_interface_struct_version
{
public:
  Init_ABMsgHeader_interface_struct_version()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ABMsgHeader_frame_number interface_struct_version(::ab_udp_msg::msg::ABMsgHeader::_interface_struct_version_type arg)
  {
    msg_.interface_struct_version = std::move(arg);
    return Init_ABMsgHeader_frame_number(msg_);
  }

private:
  ::ab_udp_msg::msg::ABMsgHeader msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::ab_udp_msg::msg::ABMsgHeader>()
{
  return ab_udp_msg::msg::builder::Init_ABMsgHeader_interface_struct_version();
}

}  // namespace ab_udp_msg

#endif  // AB_UDP_MSG__MSG__DETAIL__AB_MSG_HEADER__BUILDER_HPP_
