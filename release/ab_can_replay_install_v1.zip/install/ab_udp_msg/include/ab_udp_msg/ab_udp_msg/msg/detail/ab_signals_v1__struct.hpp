// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from ab_udp_msg:msg/ABSignalsV1.idl
// generated code does not contain a copyright notice

#ifndef AB_UDP_MSG__MSG__DETAIL__AB_SIGNALS_V1__STRUCT_HPP_
#define AB_UDP_MSG__MSG__DETAIL__AB_SIGNALS_V1__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 's_base_header'
#include "ab_udp_msg/msg/detail/ab_msg_header__struct.hpp"
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"
// Member 'camera_config'
#include "ab_udp_msg/msg/detail/es_camera_config__struct.hpp"
// Member 'vehicle_signals'
#include "ab_udp_msg/msg/detail/es_vehicle_signals__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__ab_udp_msg__msg__ABSignalsV1 __attribute__((deprecated))
#else
# define DEPRECATED__ab_udp_msg__msg__ABSignalsV1 __declspec(deprecated)
#endif

namespace ab_udp_msg
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ABSignalsV1_
{
  using Type = ABSignalsV1_<ContainerAllocator>;

  explicit ABSignalsV1_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : s_base_header(_init),
    header(_init),
    camera_config(_init),
    vehicle_signals(_init)
  {
    (void)_init;
  }

  explicit ABSignalsV1_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : s_base_header(_alloc, _init),
    header(_alloc, _init),
    camera_config(_alloc, _init),
    vehicle_signals(_alloc, _init)
  {
    (void)_init;
  }

  // field types and members
  using _s_base_header_type =
    ab_udp_msg::msg::ABMsgHeader_<ContainerAllocator>;
  _s_base_header_type s_base_header;
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _camera_config_type =
    ab_udp_msg::msg::EsCameraConfig_<ContainerAllocator>;
  _camera_config_type camera_config;
  using _vehicle_signals_type =
    ab_udp_msg::msg::EsVehicleSignals_<ContainerAllocator>;
  _vehicle_signals_type vehicle_signals;

  // setters for named parameter idiom
  Type & set__s_base_header(
    const ab_udp_msg::msg::ABMsgHeader_<ContainerAllocator> & _arg)
  {
    this->s_base_header = _arg;
    return *this;
  }
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__camera_config(
    const ab_udp_msg::msg::EsCameraConfig_<ContainerAllocator> & _arg)
  {
    this->camera_config = _arg;
    return *this;
  }
  Type & set__vehicle_signals(
    const ab_udp_msg::msg::EsVehicleSignals_<ContainerAllocator> & _arg)
  {
    this->vehicle_signals = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    ab_udp_msg::msg::ABSignalsV1_<ContainerAllocator> *;
  using ConstRawPtr =
    const ab_udp_msg::msg::ABSignalsV1_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<ab_udp_msg::msg::ABSignalsV1_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<ab_udp_msg::msg::ABSignalsV1_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      ab_udp_msg::msg::ABSignalsV1_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<ab_udp_msg::msg::ABSignalsV1_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      ab_udp_msg::msg::ABSignalsV1_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<ab_udp_msg::msg::ABSignalsV1_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<ab_udp_msg::msg::ABSignalsV1_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<ab_udp_msg::msg::ABSignalsV1_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__ab_udp_msg__msg__ABSignalsV1
    std::shared_ptr<ab_udp_msg::msg::ABSignalsV1_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__ab_udp_msg__msg__ABSignalsV1
    std::shared_ptr<ab_udp_msg::msg::ABSignalsV1_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ABSignalsV1_ & other) const
  {
    if (this->s_base_header != other.s_base_header) {
      return false;
    }
    if (this->header != other.header) {
      return false;
    }
    if (this->camera_config != other.camera_config) {
      return false;
    }
    if (this->vehicle_signals != other.vehicle_signals) {
      return false;
    }
    return true;
  }
  bool operator!=(const ABSignalsV1_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ABSignalsV1_

// alias to use template instance with default allocator
using ABSignalsV1 =
  ab_udp_msg::msg::ABSignalsV1_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace ab_udp_msg

#endif  // AB_UDP_MSG__MSG__DETAIL__AB_SIGNALS_V1__STRUCT_HPP_
