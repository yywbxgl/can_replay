// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from ab_udp_msg:msg/EsCameraConfig.idl
// generated code does not contain a copyright notice
#include "ab_udp_msg/msg/detail/es_camera_config__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


bool
ab_udp_msg__msg__EsCameraConfig__init(ab_udp_msg__msg__EsCameraConfig * msg)
{
  if (!msg) {
    return false;
  }
  // focal_length
  // camera_height
  // ppx
  // ppy
  // image_width
  // image_height
  return true;
}

void
ab_udp_msg__msg__EsCameraConfig__fini(ab_udp_msg__msg__EsCameraConfig * msg)
{
  if (!msg) {
    return;
  }
  // focal_length
  // camera_height
  // ppx
  // ppy
  // image_width
  // image_height
}

bool
ab_udp_msg__msg__EsCameraConfig__are_equal(const ab_udp_msg__msg__EsCameraConfig * lhs, const ab_udp_msg__msg__EsCameraConfig * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // focal_length
  if (lhs->focal_length != rhs->focal_length) {
    return false;
  }
  // camera_height
  if (lhs->camera_height != rhs->camera_height) {
    return false;
  }
  // ppx
  if (lhs->ppx != rhs->ppx) {
    return false;
  }
  // ppy
  if (lhs->ppy != rhs->ppy) {
    return false;
  }
  // image_width
  if (lhs->image_width != rhs->image_width) {
    return false;
  }
  // image_height
  if (lhs->image_height != rhs->image_height) {
    return false;
  }
  return true;
}

bool
ab_udp_msg__msg__EsCameraConfig__copy(
  const ab_udp_msg__msg__EsCameraConfig * input,
  ab_udp_msg__msg__EsCameraConfig * output)
{
  if (!input || !output) {
    return false;
  }
  // focal_length
  output->focal_length = input->focal_length;
  // camera_height
  output->camera_height = input->camera_height;
  // ppx
  output->ppx = input->ppx;
  // ppy
  output->ppy = input->ppy;
  // image_width
  output->image_width = input->image_width;
  // image_height
  output->image_height = input->image_height;
  return true;
}

ab_udp_msg__msg__EsCameraConfig *
ab_udp_msg__msg__EsCameraConfig__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  ab_udp_msg__msg__EsCameraConfig * msg = (ab_udp_msg__msg__EsCameraConfig *)allocator.allocate(sizeof(ab_udp_msg__msg__EsCameraConfig), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(ab_udp_msg__msg__EsCameraConfig));
  bool success = ab_udp_msg__msg__EsCameraConfig__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
ab_udp_msg__msg__EsCameraConfig__destroy(ab_udp_msg__msg__EsCameraConfig * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    ab_udp_msg__msg__EsCameraConfig__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
ab_udp_msg__msg__EsCameraConfig__Sequence__init(ab_udp_msg__msg__EsCameraConfig__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  ab_udp_msg__msg__EsCameraConfig * data = NULL;

  if (size) {
    data = (ab_udp_msg__msg__EsCameraConfig *)allocator.zero_allocate(size, sizeof(ab_udp_msg__msg__EsCameraConfig), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = ab_udp_msg__msg__EsCameraConfig__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        ab_udp_msg__msg__EsCameraConfig__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
ab_udp_msg__msg__EsCameraConfig__Sequence__fini(ab_udp_msg__msg__EsCameraConfig__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      ab_udp_msg__msg__EsCameraConfig__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

ab_udp_msg__msg__EsCameraConfig__Sequence *
ab_udp_msg__msg__EsCameraConfig__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  ab_udp_msg__msg__EsCameraConfig__Sequence * array = (ab_udp_msg__msg__EsCameraConfig__Sequence *)allocator.allocate(sizeof(ab_udp_msg__msg__EsCameraConfig__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = ab_udp_msg__msg__EsCameraConfig__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
ab_udp_msg__msg__EsCameraConfig__Sequence__destroy(ab_udp_msg__msg__EsCameraConfig__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    ab_udp_msg__msg__EsCameraConfig__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
ab_udp_msg__msg__EsCameraConfig__Sequence__are_equal(const ab_udp_msg__msg__EsCameraConfig__Sequence * lhs, const ab_udp_msg__msg__EsCameraConfig__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!ab_udp_msg__msg__EsCameraConfig__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
ab_udp_msg__msg__EsCameraConfig__Sequence__copy(
  const ab_udp_msg__msg__EsCameraConfig__Sequence * input,
  ab_udp_msg__msg__EsCameraConfig__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(ab_udp_msg__msg__EsCameraConfig);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    ab_udp_msg__msg__EsCameraConfig * data =
      (ab_udp_msg__msg__EsCameraConfig *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!ab_udp_msg__msg__EsCameraConfig__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          ab_udp_msg__msg__EsCameraConfig__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!ab_udp_msg__msg__EsCameraConfig__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
