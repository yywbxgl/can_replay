// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from ab_udp_msg:msg/EsCameraConfig.idl
// generated code does not contain a copyright notice

#ifndef AB_UDP_MSG__MSG__DETAIL__ES_CAMERA_CONFIG__BUILDER_HPP_
#define AB_UDP_MSG__MSG__DETAIL__ES_CAMERA_CONFIG__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "ab_udp_msg/msg/detail/es_camera_config__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace ab_udp_msg
{

namespace msg
{

namespace builder
{

class Init_EsCameraConfig_image_height
{
public:
  explicit Init_EsCameraConfig_image_height(::ab_udp_msg::msg::EsCameraConfig & msg)
  : msg_(msg)
  {}
  ::ab_udp_msg::msg::EsCameraConfig image_height(::ab_udp_msg::msg::EsCameraConfig::_image_height_type arg)
  {
    msg_.image_height = std::move(arg);
    return std::move(msg_);
  }

private:
  ::ab_udp_msg::msg::EsCameraConfig msg_;
};

class Init_EsCameraConfig_image_width
{
public:
  explicit Init_EsCameraConfig_image_width(::ab_udp_msg::msg::EsCameraConfig & msg)
  : msg_(msg)
  {}
  Init_EsCameraConfig_image_height image_width(::ab_udp_msg::msg::EsCameraConfig::_image_width_type arg)
  {
    msg_.image_width = std::move(arg);
    return Init_EsCameraConfig_image_height(msg_);
  }

private:
  ::ab_udp_msg::msg::EsCameraConfig msg_;
};

class Init_EsCameraConfig_ppy
{
public:
  explicit Init_EsCameraConfig_ppy(::ab_udp_msg::msg::EsCameraConfig & msg)
  : msg_(msg)
  {}
  Init_EsCameraConfig_image_width ppy(::ab_udp_msg::msg::EsCameraConfig::_ppy_type arg)
  {
    msg_.ppy = std::move(arg);
    return Init_EsCameraConfig_image_width(msg_);
  }

private:
  ::ab_udp_msg::msg::EsCameraConfig msg_;
};

class Init_EsCameraConfig_ppx
{
public:
  explicit Init_EsCameraConfig_ppx(::ab_udp_msg::msg::EsCameraConfig & msg)
  : msg_(msg)
  {}
  Init_EsCameraConfig_ppy ppx(::ab_udp_msg::msg::EsCameraConfig::_ppx_type arg)
  {
    msg_.ppx = std::move(arg);
    return Init_EsCameraConfig_ppy(msg_);
  }

private:
  ::ab_udp_msg::msg::EsCameraConfig msg_;
};

class Init_EsCameraConfig_camera_height
{
public:
  explicit Init_EsCameraConfig_camera_height(::ab_udp_msg::msg::EsCameraConfig & msg)
  : msg_(msg)
  {}
  Init_EsCameraConfig_ppx camera_height(::ab_udp_msg::msg::EsCameraConfig::_camera_height_type arg)
  {
    msg_.camera_height = std::move(arg);
    return Init_EsCameraConfig_ppx(msg_);
  }

private:
  ::ab_udp_msg::msg::EsCameraConfig msg_;
};

class Init_EsCameraConfig_focal_length
{
public:
  Init_EsCameraConfig_focal_length()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_EsCameraConfig_camera_height focal_length(::ab_udp_msg::msg::EsCameraConfig::_focal_length_type arg)
  {
    msg_.focal_length = std::move(arg);
    return Init_EsCameraConfig_camera_height(msg_);
  }

private:
  ::ab_udp_msg::msg::EsCameraConfig msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::ab_udp_msg::msg::EsCameraConfig>()
{
  return ab_udp_msg::msg::builder::Init_EsCameraConfig_focal_length();
}

}  // namespace ab_udp_msg

#endif  // AB_UDP_MSG__MSG__DETAIL__ES_CAMERA_CONFIG__BUILDER_HPP_
