// generated from rosidl_generator_c/resource/idl.h.em
// with input from ab_udp_msg:msg/ABMsgHeader.idl
// generated code does not contain a copyright notice

#ifndef AB_UDP_MSG__MSG__AB_MSG_HEADER_H_
#define AB_UDP_MSG__MSG__AB_MSG_HEADER_H_

#include "ab_udp_msg/msg/detail/ab_msg_header__struct.h"
#include "ab_udp_msg/msg/detail/ab_msg_header__functions.h"
#include "ab_udp_msg/msg/detail/ab_msg_header__type_support.h"

#endif  // AB_UDP_MSG__MSG__AB_MSG_HEADER_H_
