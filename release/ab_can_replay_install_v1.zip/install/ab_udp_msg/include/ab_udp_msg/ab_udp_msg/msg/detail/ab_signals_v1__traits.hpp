// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from ab_udp_msg:msg/ABSignalsV1.idl
// generated code does not contain a copyright notice

#ifndef AB_UDP_MSG__MSG__DETAIL__AB_SIGNALS_V1__TRAITS_HPP_
#define AB_UDP_MSG__MSG__DETAIL__AB_SIGNALS_V1__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "ab_udp_msg/msg/detail/ab_signals_v1__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 's_base_header'
#include "ab_udp_msg/msg/detail/ab_msg_header__traits.hpp"
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"
// Member 'camera_config'
#include "ab_udp_msg/msg/detail/es_camera_config__traits.hpp"
// Member 'vehicle_signals'
#include "ab_udp_msg/msg/detail/es_vehicle_signals__traits.hpp"

namespace ab_udp_msg
{

namespace msg
{

inline void to_flow_style_yaml(
  const ABSignalsV1 & msg,
  std::ostream & out)
{
  out << "{";
  // member: s_base_header
  {
    out << "s_base_header: ";
    to_flow_style_yaml(msg.s_base_header, out);
    out << ", ";
  }

  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: camera_config
  {
    out << "camera_config: ";
    to_flow_style_yaml(msg.camera_config, out);
    out << ", ";
  }

  // member: vehicle_signals
  {
    out << "vehicle_signals: ";
    to_flow_style_yaml(msg.vehicle_signals, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ABSignalsV1 & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: s_base_header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "s_base_header:\n";
    to_block_style_yaml(msg.s_base_header, out, indentation + 2);
  }

  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: camera_config
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "camera_config:\n";
    to_block_style_yaml(msg.camera_config, out, indentation + 2);
  }

  // member: vehicle_signals
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "vehicle_signals:\n";
    to_block_style_yaml(msg.vehicle_signals, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ABSignalsV1 & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace ab_udp_msg

namespace rosidl_generator_traits
{

[[deprecated("use ab_udp_msg::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const ab_udp_msg::msg::ABSignalsV1 & msg,
  std::ostream & out, size_t indentation = 0)
{
  ab_udp_msg::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use ab_udp_msg::msg::to_yaml() instead")]]
inline std::string to_yaml(const ab_udp_msg::msg::ABSignalsV1 & msg)
{
  return ab_udp_msg::msg::to_yaml(msg);
}

template<>
inline const char * data_type<ab_udp_msg::msg::ABSignalsV1>()
{
  return "ab_udp_msg::msg::ABSignalsV1";
}

template<>
inline const char * name<ab_udp_msg::msg::ABSignalsV1>()
{
  return "ab_udp_msg/msg/ABSignalsV1";
}

template<>
struct has_fixed_size<ab_udp_msg::msg::ABSignalsV1>
  : std::integral_constant<bool, has_fixed_size<ab_udp_msg::msg::ABMsgHeader>::value && has_fixed_size<ab_udp_msg::msg::EsCameraConfig>::value && has_fixed_size<ab_udp_msg::msg::EsVehicleSignals>::value && has_fixed_size<std_msgs::msg::Header>::value> {};

template<>
struct has_bounded_size<ab_udp_msg::msg::ABSignalsV1>
  : std::integral_constant<bool, has_bounded_size<ab_udp_msg::msg::ABMsgHeader>::value && has_bounded_size<ab_udp_msg::msg::EsCameraConfig>::value && has_bounded_size<ab_udp_msg::msg::EsVehicleSignals>::value && has_bounded_size<std_msgs::msg::Header>::value> {};

template<>
struct is_message<ab_udp_msg::msg::ABSignalsV1>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // AB_UDP_MSG__MSG__DETAIL__AB_SIGNALS_V1__TRAITS_HPP_
