// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from ab_udp_msg:msg/EsVehicleSignals.idl
// generated code does not contain a copyright notice

#ifndef AB_UDP_MSG__MSG__DETAIL__ES_VEHICLE_SIGNALS__STRUCT_H_
#define AB_UDP_MSG__MSG__DETAIL__ES_VEHICLE_SIGNALS__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/EsVehicleSignals in the package ab_udp_msg.
typedef struct ab_udp_msg__msg__EsVehicleSignals
{
  /// z axis
  float longitudinal_velocity;
  /// z axis
  float longitudinal_acceleration;
  float yaw_rate;
  float speed_o_speed;
} ab_udp_msg__msg__EsVehicleSignals;

// Struct for a sequence of ab_udp_msg__msg__EsVehicleSignals.
typedef struct ab_udp_msg__msg__EsVehicleSignals__Sequence
{
  ab_udp_msg__msg__EsVehicleSignals * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} ab_udp_msg__msg__EsVehicleSignals__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // AB_UDP_MSG__MSG__DETAIL__ES_VEHICLE_SIGNALS__STRUCT_H_
