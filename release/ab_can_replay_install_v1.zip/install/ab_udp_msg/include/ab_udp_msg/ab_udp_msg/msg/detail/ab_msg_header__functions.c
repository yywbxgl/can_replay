// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from ab_udp_msg:msg/ABMsgHeader.idl
// generated code does not contain a copyright notice
#include "ab_udp_msg/msg/detail/ab_msg_header__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `s_frame_name`
// Member `s_module_version`
#include "rosidl_runtime_c/string_functions.h"

bool
ab_udp_msg__msg__ABMsgHeader__init(ab_udp_msg__msg__ABMsgHeader * msg)
{
  if (!msg) {
    return false;
  }
  // interface_struct_version
  // frame_number
  // s_frame_name
  if (!rosidl_runtime_c__String__init(&msg->s_frame_name)) {
    ab_udp_msg__msg__ABMsgHeader__fini(msg);
    return false;
  }
  // s_module_version
  if (!rosidl_runtime_c__String__init(&msg->s_module_version)) {
    ab_udp_msg__msg__ABMsgHeader__fini(msg);
    return false;
  }
  return true;
}

void
ab_udp_msg__msg__ABMsgHeader__fini(ab_udp_msg__msg__ABMsgHeader * msg)
{
  if (!msg) {
    return;
  }
  // interface_struct_version
  // frame_number
  // s_frame_name
  rosidl_runtime_c__String__fini(&msg->s_frame_name);
  // s_module_version
  rosidl_runtime_c__String__fini(&msg->s_module_version);
}

bool
ab_udp_msg__msg__ABMsgHeader__are_equal(const ab_udp_msg__msg__ABMsgHeader * lhs, const ab_udp_msg__msg__ABMsgHeader * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // interface_struct_version
  if (lhs->interface_struct_version != rhs->interface_struct_version) {
    return false;
  }
  // frame_number
  if (lhs->frame_number != rhs->frame_number) {
    return false;
  }
  // s_frame_name
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->s_frame_name), &(rhs->s_frame_name)))
  {
    return false;
  }
  // s_module_version
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->s_module_version), &(rhs->s_module_version)))
  {
    return false;
  }
  return true;
}

bool
ab_udp_msg__msg__ABMsgHeader__copy(
  const ab_udp_msg__msg__ABMsgHeader * input,
  ab_udp_msg__msg__ABMsgHeader * output)
{
  if (!input || !output) {
    return false;
  }
  // interface_struct_version
  output->interface_struct_version = input->interface_struct_version;
  // frame_number
  output->frame_number = input->frame_number;
  // s_frame_name
  if (!rosidl_runtime_c__String__copy(
      &(input->s_frame_name), &(output->s_frame_name)))
  {
    return false;
  }
  // s_module_version
  if (!rosidl_runtime_c__String__copy(
      &(input->s_module_version), &(output->s_module_version)))
  {
    return false;
  }
  return true;
}

ab_udp_msg__msg__ABMsgHeader *
ab_udp_msg__msg__ABMsgHeader__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  ab_udp_msg__msg__ABMsgHeader * msg = (ab_udp_msg__msg__ABMsgHeader *)allocator.allocate(sizeof(ab_udp_msg__msg__ABMsgHeader), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(ab_udp_msg__msg__ABMsgHeader));
  bool success = ab_udp_msg__msg__ABMsgHeader__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
ab_udp_msg__msg__ABMsgHeader__destroy(ab_udp_msg__msg__ABMsgHeader * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    ab_udp_msg__msg__ABMsgHeader__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
ab_udp_msg__msg__ABMsgHeader__Sequence__init(ab_udp_msg__msg__ABMsgHeader__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  ab_udp_msg__msg__ABMsgHeader * data = NULL;

  if (size) {
    data = (ab_udp_msg__msg__ABMsgHeader *)allocator.zero_allocate(size, sizeof(ab_udp_msg__msg__ABMsgHeader), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = ab_udp_msg__msg__ABMsgHeader__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        ab_udp_msg__msg__ABMsgHeader__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
ab_udp_msg__msg__ABMsgHeader__Sequence__fini(ab_udp_msg__msg__ABMsgHeader__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      ab_udp_msg__msg__ABMsgHeader__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

ab_udp_msg__msg__ABMsgHeader__Sequence *
ab_udp_msg__msg__ABMsgHeader__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  ab_udp_msg__msg__ABMsgHeader__Sequence * array = (ab_udp_msg__msg__ABMsgHeader__Sequence *)allocator.allocate(sizeof(ab_udp_msg__msg__ABMsgHeader__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = ab_udp_msg__msg__ABMsgHeader__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
ab_udp_msg__msg__ABMsgHeader__Sequence__destroy(ab_udp_msg__msg__ABMsgHeader__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    ab_udp_msg__msg__ABMsgHeader__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
ab_udp_msg__msg__ABMsgHeader__Sequence__are_equal(const ab_udp_msg__msg__ABMsgHeader__Sequence * lhs, const ab_udp_msg__msg__ABMsgHeader__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!ab_udp_msg__msg__ABMsgHeader__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
ab_udp_msg__msg__ABMsgHeader__Sequence__copy(
  const ab_udp_msg__msg__ABMsgHeader__Sequence * input,
  ab_udp_msg__msg__ABMsgHeader__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(ab_udp_msg__msg__ABMsgHeader);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    ab_udp_msg__msg__ABMsgHeader * data =
      (ab_udp_msg__msg__ABMsgHeader *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!ab_udp_msg__msg__ABMsgHeader__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          ab_udp_msg__msg__ABMsgHeader__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!ab_udp_msg__msg__ABMsgHeader__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
