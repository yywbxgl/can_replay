// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from ab_udp_msg:msg/EsCameraConfig.idl
// generated code does not contain a copyright notice

#ifndef AB_UDP_MSG__MSG__DETAIL__ES_CAMERA_CONFIG__STRUCT_H_
#define AB_UDP_MSG__MSG__DETAIL__ES_CAMERA_CONFIG__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/EsCameraConfig in the package ab_udp_msg.
typedef struct ab_udp_msg__msg__EsCameraConfig
{
  float focal_length;
  float camera_height;
  float ppx;
  float ppy;
  uint32_t image_width;
  uint32_t image_height;
} ab_udp_msg__msg__EsCameraConfig;

// Struct for a sequence of ab_udp_msg__msg__EsCameraConfig.
typedef struct ab_udp_msg__msg__EsCameraConfig__Sequence
{
  ab_udp_msg__msg__EsCameraConfig * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} ab_udp_msg__msg__EsCameraConfig__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // AB_UDP_MSG__MSG__DETAIL__ES_CAMERA_CONFIG__STRUCT_H_
