// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from ab_udp_msg:msg/ABMsgHeader.idl
// generated code does not contain a copyright notice

#ifndef AB_UDP_MSG__MSG__DETAIL__AB_MSG_HEADER__STRUCT_HPP_
#define AB_UDP_MSG__MSG__DETAIL__AB_MSG_HEADER__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__ab_udp_msg__msg__ABMsgHeader __attribute__((deprecated))
#else
# define DEPRECATED__ab_udp_msg__msg__ABMsgHeader __declspec(deprecated)
#endif

namespace ab_udp_msg
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ABMsgHeader_
{
  using Type = ABMsgHeader_<ContainerAllocator>;

  explicit ABMsgHeader_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->interface_struct_version = 0.0f;
      this->frame_number = 0ull;
      this->s_frame_name = "";
      this->s_module_version = "";
    }
  }

  explicit ABMsgHeader_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : s_frame_name(_alloc),
    s_module_version(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->interface_struct_version = 0.0f;
      this->frame_number = 0ull;
      this->s_frame_name = "";
      this->s_module_version = "";
    }
  }

  // field types and members
  using _interface_struct_version_type =
    float;
  _interface_struct_version_type interface_struct_version;
  using _frame_number_type =
    uint64_t;
  _frame_number_type frame_number;
  using _s_frame_name_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _s_frame_name_type s_frame_name;
  using _s_module_version_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _s_module_version_type s_module_version;

  // setters for named parameter idiom
  Type & set__interface_struct_version(
    const float & _arg)
  {
    this->interface_struct_version = _arg;
    return *this;
  }
  Type & set__frame_number(
    const uint64_t & _arg)
  {
    this->frame_number = _arg;
    return *this;
  }
  Type & set__s_frame_name(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->s_frame_name = _arg;
    return *this;
  }
  Type & set__s_module_version(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->s_module_version = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    ab_udp_msg::msg::ABMsgHeader_<ContainerAllocator> *;
  using ConstRawPtr =
    const ab_udp_msg::msg::ABMsgHeader_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<ab_udp_msg::msg::ABMsgHeader_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<ab_udp_msg::msg::ABMsgHeader_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      ab_udp_msg::msg::ABMsgHeader_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<ab_udp_msg::msg::ABMsgHeader_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      ab_udp_msg::msg::ABMsgHeader_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<ab_udp_msg::msg::ABMsgHeader_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<ab_udp_msg::msg::ABMsgHeader_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<ab_udp_msg::msg::ABMsgHeader_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__ab_udp_msg__msg__ABMsgHeader
    std::shared_ptr<ab_udp_msg::msg::ABMsgHeader_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__ab_udp_msg__msg__ABMsgHeader
    std::shared_ptr<ab_udp_msg::msg::ABMsgHeader_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ABMsgHeader_ & other) const
  {
    if (this->interface_struct_version != other.interface_struct_version) {
      return false;
    }
    if (this->frame_number != other.frame_number) {
      return false;
    }
    if (this->s_frame_name != other.s_frame_name) {
      return false;
    }
    if (this->s_module_version != other.s_module_version) {
      return false;
    }
    return true;
  }
  bool operator!=(const ABMsgHeader_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ABMsgHeader_

// alias to use template instance with default allocator
using ABMsgHeader =
  ab_udp_msg::msg::ABMsgHeader_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace ab_udp_msg

#endif  // AB_UDP_MSG__MSG__DETAIL__AB_MSG_HEADER__STRUCT_HPP_
