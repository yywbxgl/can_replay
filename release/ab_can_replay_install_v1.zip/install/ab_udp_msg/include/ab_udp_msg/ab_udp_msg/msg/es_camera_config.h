// generated from rosidl_generator_c/resource/idl.h.em
// with input from ab_udp_msg:msg/EsCameraConfig.idl
// generated code does not contain a copyright notice

#ifndef AB_UDP_MSG__MSG__ES_CAMERA_CONFIG_H_
#define AB_UDP_MSG__MSG__ES_CAMERA_CONFIG_H_

#include "ab_udp_msg/msg/detail/es_camera_config__struct.h"
#include "ab_udp_msg/msg/detail/es_camera_config__functions.h"
#include "ab_udp_msg/msg/detail/es_camera_config__type_support.h"

#endif  // AB_UDP_MSG__MSG__ES_CAMERA_CONFIG_H_
